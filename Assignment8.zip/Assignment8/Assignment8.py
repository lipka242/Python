# -------------------------------------#
# JLipka
# Assignment 8
# December 17, 2018
# IT FDN 100B
# -------------------------------------#
class Person(object):
    ID = ","
    Name = ","
    Price = ","
    """Doc String """
    # --Fields--
    # --Constructor--
    def __init__(self, ID, Name, Price):
        # Attributes
        self.__ID = ID
        self.__Name = Name
        self.__Price = Price
# --Properties--
    #ID
    @property
    def ID(self):
        return self.__ID
    @ID.setter
    def ID(self, Value):
        self.__ID = Value
    #Name
    @property
    def Name(self):
        return self.__Name
    @Name.setter
    def Name(self, Value):
        self.__Name = Value
    @property
    def Price(self):
        return self.__Price
    @Price.setter
    def Price(self, Value):
        self.__Price = Value
# --Methods--
    def ToString(self):
        return self.ID + "," + self.Name + "," + self.Price
    def __str__(self):
        return self.ToString()
# --End of class--
    # --- Use the class ----
    # by making an object!
    #objP1 = Person("1", "Milk", "3.99")
    #objP2 = Person("2", "Bread", "2.99")
    #objP2.ID = "2"
    #objP2.Name = "Bread"
    #objP2.Price = "2.99"
    #print(objP1.ToString())
    #print("-------------")
    #print(objP2.ToString())
#Data
objFile = ("Products.txt","w")
strUserInput = None #A string which holds user input
#Processing
def WriteProductUserInput(File):
  try:
    print("Type in a Product Id, Name, and Price you want to add to the file")
    print("(Enter 'Exit' to quit!)")
    while(True):
      strUserInput = input("Enter the Id, Name, and Price (ex. 1,ProductA,9.99): ")
      if(strUserInput.lower() == "exit"): break
      else: File.write(strUserInput + "\n")
  except Exception as e:
    print("Error: " + str(e))
def ReadAllFileData(File, Message="Contents of File"):
  try:
    print(Message)
    File.seek(0)
    print(File.read())
  except Exception as e:
    print("Error: " + str(e))
#I/O
try:
  objFile = open("Products.txt", "r+")
  ReadAllFileData(objFile, "Here is the current data:")
  WriteProductUserInput(objFile)
  ReadAllFileData(objFile, "Here is this data was saved:")
except FileNotFoundError as e:
     print("Error: " + str(e) + "\n Please check the file name")
except Exception as e:
    print("Error: " + str(e))
finally:
  if(objFile != None):objFile.close()